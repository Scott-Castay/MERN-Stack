export const NotFound = (props) => {
    return 'Page not found.';
  };
  
  export default NotFound;