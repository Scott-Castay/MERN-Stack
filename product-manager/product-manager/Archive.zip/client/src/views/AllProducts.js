import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import {
  deleteProductById,
  getAllProducts,
} from '../services/internalApiService';

// Named export: import { AllDestinations, Name2 } from './components/AllDestinations';
export const AllProducts = (props) => {
  const [products, setProducts] = useState([]);

  /* 
  Empty arr as second arguments means it will only run on mount, not on other
  state changes so we don't keep re-fetching data.
  */
  useEffect(() => {
    getAllProducts()
      .then((data) => {
        console.log(data);
        setProducts(data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const handleDeleteClick = (idToDelete) => {
    deleteProductById(idToDelete)
      .then((deletedProduct) => {
        const filteredProducts = products.filter((product) => {
          return product._id !== idToDelete;
        });

        console.log('deletedProduct:', deletedProduct);
        setProducts(filteredProducts);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="w-50 mx-auto text-center">
      <h2>Products!</h2>

      {products.map((products) => {
        const { _id, title } =
          products;

        return (
          <div key={_id} className="shadow mb-4 rounded border p-4">
            <Link to={`/products/${_id}`}>
              <h4>{title}</h4>
            </Link>
            {/* <p>{description}</p> */}
            {/* <h5>Travel Seasons:</h5> */}
            {/* Display only the `true` seasons. */}
            {/* <ul className="list-group">
              {summer && <li className="list-group-item">Summer</li>}
              {winter && <li className="list-group-item">Winter</li>}
              {spring && <li className="list-group-item">Spring</li>}
              {fall && <li className="list-group-item">Fall</li>}
            </ul> */}

            <div className="mt-2">
              <button
                onClick={(e) => {
                  handleDeleteClick(_id);
                }}
                className="btn btn-sm btn-outline-danger mx-1"
              >
                Delete
              </button>

              <Link
                to={`/products/${_id}/edit`}
                className="btn btn-sm btn-outline-warning mx-1"
              >
                Edit
              </Link>
            </div>
          </div>
        );
      })}
    </div>
  );
};

// Only 1 default per file: import AllDestinations from './components/AllDestinations';
// When importing default, you can choose any name.
export default AllProducts;